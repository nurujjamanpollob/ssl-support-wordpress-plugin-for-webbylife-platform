This WordPress plugin offers a simple way to verify ACME verification challenges.

It works for only HTTP challenges, and it is designed to be used with the ACME protocol for obtaining SSL/TLS certificates.

